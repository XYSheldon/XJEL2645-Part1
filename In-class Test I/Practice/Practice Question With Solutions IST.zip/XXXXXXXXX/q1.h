#ifndef Q1_H
#define Q1_H
// DO NOT MODIFY THIS FILE!
bool is_even(int a);
#endif  // Q1_H
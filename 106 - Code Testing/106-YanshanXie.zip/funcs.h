#ifndef FUNCS_H
#define FUNCS_H

// returns the sum of two numbers
int sum(int a, int b);
// returns the square of a number
double sqr(double a);
// returns the minimum value in an array
int min_array_value(int array[], int n);

// function returns the biggest value out of a and b
int biggest(int a, int b);

// returns the length of the hypotenuse of a right-angle triangle
double hypotenuse(double a, double b);

// returns the BMI of a person of a given height (m) and weight (kg)
// for invalid negative values, the function should return -1.0
double bmi(double height, double weight);

// the function returns the average value of an array of integer
// note that it should return a double
double array_average(int array[], int n);

#endif
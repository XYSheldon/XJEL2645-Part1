#include "q1.h"

// import any required libraries here

float calculator(float a, float b, char operation) {

}
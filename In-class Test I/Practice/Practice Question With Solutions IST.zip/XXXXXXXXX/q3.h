#ifndef Q3_H
#define Q3_H
// DO NOT MODIFY THIS FILE!
int min_array_value(int array[], int n);
#endif  // Q3_H
#ifndef Q4_H
#define Q4_H
// DO NOT MODIFY THIS FILE!
double mean_array_value(int array[], int n);
#endif  // Q4_H
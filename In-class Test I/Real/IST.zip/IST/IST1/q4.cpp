#include "q4.h"

// Add any required libraries above

std::string jmp_mnemonic(std::bitset<16> instruction) {

}
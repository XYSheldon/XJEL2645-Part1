#include "q5.h"

#include <iostream>
#include <cmath>
// import any required libraries above

float* func(int n, float T) {

}
#ifndef Q2_H
#define Q2_H
// DO NOT MODIFY THIS FILE!
bool multiple(int a);
#endif  // Q2_H
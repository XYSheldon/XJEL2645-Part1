#include "q2.h"

// import any required libraries here

float resistor_network(const float values[], int n, char type) {

}
#ifndef MAIN_H
#define MAIN_H

#include "funcs.h"
#include "tests.h"

#endif
#include "q3.h"
#include <complex>
// Add any required libraries above

Polar rlc_impedance(double R, double L, double C, double f) {

}